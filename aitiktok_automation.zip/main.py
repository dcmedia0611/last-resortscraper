from moviepy.editor import VideoFileClip, AudioFileClip, TextClip, CompositeVideoClip

print("✅ MoviePy successfully imported!")
